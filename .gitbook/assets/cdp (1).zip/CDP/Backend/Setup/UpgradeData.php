<?php

namespace CDP\Backend\Setup;

use Magento\Framework\App\Config\Storage\WriterInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;

use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Customer\Setup\CustomerSetup;

/**
 * Class UpgradeData
 * @package CDP\Backend\Setup
 */
class UpgradeData implements UpgradeDataInterface
{
    const UPDATE_CRON_STRING_PATH = "cdp/crontab/license";

    /** @var WriterInterface */
    protected $configWriter;

    /**
     * @var ModuleDataSetupInterface
     */
    private $moduleDataSetup;
    /**
     * @var CustomerSetup
     */
    private $customerSetupFactory;


    /**
     * UpgradeData constructor.
     * @param WriterInterface $configWriter
     */
    public function __construct(
        WriterInterface $configWriter,
        ModuleDataSetupInterface $moduleDataSetup,
        CustomerSetupFactory $customerSetupFactory
    )
    {
        $this->configWriter = $configWriter;
        $this->moduleDataSetup = $moduleDataSetup;
        $this->customerSetupFactory = $customerSetupFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        if (version_compare($context->getVersion(), '1.1.1') < 0) {
            $cronExpression = $this->_generateCronExpression();
            $this->configWriter->save(self::UPDATE_CRON_STRING_PATH, $cronExpression);
        }

//        $this->moduleDataSetup->getConnection()->startSetup();
//        /** @var CustomerSetup $customerSetup */
//        $customerSetup = $this->customerSetupFactory->create(['setup' => $this->moduleDataSetup]);
//        $customerSetup->addAttribute(
//            \Magento\Customer\Model\Customer::ENTITY,
//            'cdp_type',
//            [
//                'type' => 'varchar',
//                'label' => 'CDP type',
//                'input' => 'text',
//                'source' => '',
//                'required' => false,
//                'visible' => true,
//                'position' => 500,
//                'system' => false,
//                'backend' => ''
//            ]
//        );
//
//        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'cdp_type')->addData([
//            'used_in_forms' => [
//                'adminhtml_customer'
//            ]
//        ]);
//        $attribute->save();
//
//        $this->moduleDataSetup->getConnection()->endSetup();

        $installer->endSetup();
    }

    /**
     * @return string
     */
    protected function _generateCronExpression()
    {
        $minute = rand(0, 59);
        $hour = rand(-2, 6);
        $dayOfWeek = rand(0, 6);
        if ($hour < 0) {
            $hour += 24;
        }
        return $minute . ' ' . $hour . ' * * ' . $dayOfWeek;
    }
}
