<?php
namespace CDP\Backend\Model;

use Magento\Framework\Config\ConfigOptionsListConstants;

/**
 * CDP_Admin Feed model
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Feed extends \Magento\AdminNotification\Model\Feed
{

    const XML_FREQUENCY_PATH = 'system/adminnotification/frequency';

    /**
     * Feed url for CDP Feed
     *
     * @var string
     */
    protected $_cdpFeedUrl = 'http://weltpixel.com/notifications.rss';

    /**
     * Retrieve feed url
     *
     * @return string
     */
    public function getFeedUrl()
    {
        return $this->_cdpFeedUrl;
    }

    /**
     * Retrieve Last update time
     *
     * @return int
     */
    public function getLastUpdate()
    {
        return $this->_cacheManager->load('cdp_notifications_lastcheck');
    }

    /**
     * Set last update time (now)
     *
     * @return $this
     */
    public function setLastUpdate()
    {
        $this->_cacheManager->save(time(), 'cdp_notifications_lastcheck');
        return $this;
    }
}
