<?php


namespace CDP\Insight\Api;


interface CustomerInterface
{
    /**
     * Returns greeting message to user
     *
     * @api
     * @param string $customerId Id.
     * @return detail customer
     */
    public function getDetail($customerId);

    /**
     * POST for attribute api
     * @param mixed $params
     * @return array
     */
    public function updCustomer($params);
}