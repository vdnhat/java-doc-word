<?php

namespace CDP\Insight\Block;

/**
 * Class \CDP\Insight\Block\Compare
 */
class Compare extends \Magento\Framework\View\Element\Template
{

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Catalog\CustomerData\CompareProducts $compareProducts,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        \CDP\Insight\Helper\Data $helper,
        \CDP\Insight\Block\Core $core,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->compareProducts = $compareProducts;
        $this->productRepository = $productRepository;
        $this->helper = $helper;
        $this->core = $core;
    }

    /*
        * Get current compare product list
        */
    public function getProducts(){
        $compareProducts = $this->compareProducts->getSectionData();
        $products = [];
        foreach ($compareProducts['items'] as $item) {
            $product = $this->productRepository->getById($item['id']);

            $productDetail = [];
            $productDetail['type'] = 'product';
            $productDetail['sku'] = $product->getSku();
            $productDetail['page_url'] = $product->getProductUrl();
            $productDetail['image_url'] = $this->helper->getImageUrlProduct($product);
            $productDetail['name'] = html_entity_decode($product->getName());
            $productDetail['id'] = $this->helper->getGtmProductId($product);
            $productDetail['price'] = $product->getPriceInfo()->getPrice('final_price')->getValue();
            $productDetail['brand'] = $this->helper->getGtmBrand($product);
            $productDetail['currency'] = $this->helper->getCurrencyCode();

            $category_array =  $this->helper->getArrayCategoryFromCategoryIds($product->getCategoryIds());
            $productDetail['main_category'] = $category_array[0];
            $productDetail['category_level_1'] = isset($category_array[1]) ? $category_array[1] : '';
            $productDetail['category_level_2'] = isset($category_array[2]) ? $category_array[2] : '';
            $productDetail['category'] = implode('/', $category_array);
            $products[] = $productDetail;
        }

        return $products;
    }
}