var config = {
    map: {
        '*': {
            cdp_gtm: 'CDP_Insight/js/cdp_gtm',
            cdp_persistentLayer: 'CDP_Insight/js/cdp_persistentlayer'
        }
    }
};