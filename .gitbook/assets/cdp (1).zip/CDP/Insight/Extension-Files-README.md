Important notes:
- Extension files for Magento versions 2.3 or higher. 
- Files NOT compatible with Magento version 2.0 - 2.2.x.
- Using different set of files for each Magento version for best performance.

API Update custom attribute customer

- API: DOMAIN/rest/V1/custom/upd-customer
- Method: POST
- Params:
    {
      "params": {
        "CustomerId": "2",
          "Entity_Attributes": {
            "cdp_type": "CP7",
            "cp7_type": "CP8"
          }
      }
    }
 
