<?php

namespace CDP\Insight\Model;

use CDP\Insight\Api\CustomerInterface;

class Customer implements CustomerInterface
{
    public function __construct(
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface,
        \Magento\Customer\Model\CustomerFactory $customerFactory
    )
    {
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
        $this->_customerFactory = $customerFactory;

    }

    public function getDetail($customerId)
    {
        return "Hello, " . $customerId;
    }

    public function updCustomer($params)
    {
        $arr_attribute = $params['Entity_Attributes'];
        $customer_id = $params['CustomerId'];


        $customer = $this->_customerFactory->create()->load($customer_id)->getDataModel();

        foreach ($arr_attribute as $attribute_code => $value) {
            $customer->setCustomAttribute($attribute_code, $value);
        }

        $this->_customerRepositoryInterface->save($customer);

        return array(
            "data" => array(
                'status' => 200,
                'customer_id' => $customer_id
            )
        );
    }
}