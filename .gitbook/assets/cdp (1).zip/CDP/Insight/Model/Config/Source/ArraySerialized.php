<?php

namespace CDP\Insight\Model\Config\Source;

class ArraySerialized extends \CDP\Insight\Model\Config\Source\Serialized
{
    /**
     * Unset array element with '__empty' key
     *
     * @return \CDP\Insight\Model\Config\Source\Serialized
     */
    public function beforeSave()
    {
        $value = $this->getValue();
        if (is_array($value)) {
            unset($value['__empty']);
        }
        $this->setValue($value);

        return parent::beforeSave();
    }
}
