<?php

namespace CDP\Insight\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class CustomerInfo
 *
 * @package CDP\Insight\Model\Config\Source
 */

class CustomerInfo implements ArrayInterface
{
    /**
     * Return list of Id Options
     *
     * @return array Format: array(array('value' => '<value>', 'label' => '<label>'), ...)
     */
    public function toOptionArray()
    {
        return array(
            array(
                'value' => 'user_id',
                'label' => __('User ID')
            ),
            array(
                'value' => 'name',
                'label' => __('Name')
            ),
            array(
                'value' => 'email',
                'label' => __('Email')
            ),
            array(
                'value' => 'phone',
                'label' => __('Phone')
            ),
            array(
                'value' => 'address',
                'label' => __('Address')
            ),
            array(
                'value' => 'country',
                'label' => __('Country')
            ),
            array(
                'value' => 'city',
                'label' => __('City')
            ),
            array(
                'value' => 'province',
                'label' => __('Provice')
            ),
        );
    }
}
