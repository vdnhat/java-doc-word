<?php

namespace CDP\Insight\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class Hash
 *
 * @package CDP\Insight\Model\Config\Source
 */
class Hash implements ArrayInterface
{
    public function __construct(
    ) {

    }

    /**
     * Return list of Id Options
     *
     * @return array Format: array(array('value' => '<value>', 'label' => '<label>'), ...)
     */
    public function toOptionArray()
    {
        return array(
            array(
                'value' => 'none',
                'label' => __('-- None -- ')
            ),
            array(
                'value' => 'md5',
                'label' => __('Md5')
            ),
        );
    }
}