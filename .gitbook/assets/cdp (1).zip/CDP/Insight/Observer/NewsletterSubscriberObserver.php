<?php

namespace CDP\Insight\Observer;

use Magento\Framework\Event\ObserverInterface;

class NewsletterSubscriberObserver implements ObserverInterface
{
    /**
     * @var \CDP\Insight\Helper\Data
     */
    protected $helper;

    /**
     * @param \CDP\Insight\Helper\Data $helper
     */
    public function __construct(\CDP\Insight\Helper\Data $helper,
                                \Magento\Customer\Model\Session $customerSession)
    {
        $this->helper = $helper;
        $this->customerSession = $customerSession;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return $this
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        if (!$this->helper->isEnabled()) {
            return $this;
        }

        $subscriber = $observer->getEvent()->getSubscriber();
        $email = $subscriber->getEmail();

        $data_subscribe = [];

        $data_subscribe['event'] = 'NewsletterSubsribe';
        $data_subscribe['eventLabel'] = 'NewsletterSubsribe';

        $data_subscribe['ecommerce'] = [];
        $data_subscribe['ecommerce']['object'] = 'email';
        $data_subscribe['ecommerce']['event'] = 'subscrible';

        $data_subscribe['ecommerce']['data']['extra']['email'] = $email;

        $this->customerSession->setNewsletterSubscribeData($data_subscribe);

        return $this;
    }
}