<?php

namespace CDP\Insight\Observer;

use Magento\Framework\Event\ObserverInterface;

class CompareAddProductObserver implements ObserverInterface
{
    /**
     * @var \CDP\Insight\Helper\Data
     */
    protected $helper;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;


    /**
     * @param \CDP\Insight\Helper\Data $helper
     */
    public function __construct(\CDP\Insight\Helper\Data $helper,
                                \Magento\Customer\Model\Session $customerSession)
    {
        $this->helper = $helper;
        $this->customerSession = $customerSession;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return self
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        if (!$this->helper->isEnabled()) {
            return $this;
        }

        $product = $observer->getData('product');

        $this->customerSession->setAddToCompareData($this->helper->addToComparePushData($product));

        return $this;
    }
}