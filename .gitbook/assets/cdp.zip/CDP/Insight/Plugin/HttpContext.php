<?php

namespace CDP\Insight\Plugin;

class HttpContext
{

    /**
     * GoogleTagManager context
     */
    const CONTEXT_GTM = 'cdp_gtm';

    /**
     * @var \CDP\Insight\Helper\Data
     */
    protected $helper;

    /**
     * @param \CDP\Insight\Helper\Data $helper
     */
    public function __construct(
        \CDP\Insight\Helper\Data $helper
    )
    {
        $this->helper = $helper;
    }

    /**
     * @param \Magento\Framework\App\Http\Context $subject
     * @return null
     */
    public function beforeGetVaryString(
        \Magento\Framework\App\Http\Context $subject
    ) {
        if ($this->helper->isEnabled()) {
            $subject->setValue(
                self::CONTEXT_GTM,
                'isEnabled',
                ''
            );
        }
        return null;
    }
}