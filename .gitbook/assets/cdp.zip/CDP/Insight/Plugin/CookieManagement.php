<?php

namespace CDP\Insight\Plugin;

class CookieManagement
{
    /**
     * @var \CDP\Insight\Helper\Data
     */
    protected $helper;

    /**
     * @var \CDP\Insight\Model\CookieManager
     */
    protected $cookieManager;

    /**
     * @param \CDP\Insight\Helper\Data $helper
     * @param \CDP\Insight\Model\CookieManager $cookieManager
     */
    public function __construct(
        \CDP\Insight\Helper\Data $helper,
        \CDP\Insight\Model\CookieManager $cookieManager
    )
    {
        $this->helper = $helper;
        $this->cookieManager = $cookieManager;
    }

    /**
     * @param \Magento\Framework\App\FrontController $subject
     * @param $result
     * @return mixed
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterDispatch(
        \Magento\Framework\App\FrontController $subject,
        $result
    ) {
        if (!$this->helper->isEnabled()) {
            return $result;
        }

        $this->cookieManager->setGtmCookies();
        return $result;

    }
}