<?php

namespace CDP\Insight\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class Id
 *
 * @package CDP\Insight\Model\Config\Source
 */
class Id implements ArrayInterface
{

    /**
     * Return list of Id Options
     *
     * @return array Format: array(array('value' => '<value>', 'label' => '<label>'), ...)
     */
    public function toOptionArray()
    {
        return array(
            array(
                'value' => 'user_id',
                'label' => __('User ID')
            ),
            array(
                'value' => 'phone',
                'label' => __('Phone')
            ),
            array(
                'value' => 'email',
                'label' => __('Email')
            ),
        );
    }
}