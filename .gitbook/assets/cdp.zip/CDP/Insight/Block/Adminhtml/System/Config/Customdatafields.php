<?php

namespace CDP\Insight\Block\Adminhtml\System\Config;

class Customdatafields extends
 \Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray
{
    /**
     * @var \CDP\Insight\Block\Adminhtml\System\Config\Select
     */
    public $customerInfoRenderer; //statusRenderer

    /**
     * @var \CDP\Insight\Block\Adminhtml\System\Config\Select
     */
    public $typeHashRenderer; //automationRenderer

    /**
     * @var \CDP\Insight\Model\Config\Source\Hash
     */
    public $typeHash; // $programFactory

    /**
     * @var \Magento\Framework\Data\Form\Element\Factory
     */
    public $elementFactory;

    /**
     * Customdatafields constructor.
     *
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Data\Form\Element\Factory $elementFactory
     * @param \CDP\Insight\Model\Config\Source\Hash $programFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Data\Form\Element\Factory $elementFactory,
        \CDP\Insight\Model\Config\Source\Hash $typeHash,
        array $data = []
    ) {
        $this->elementFactory = $elementFactory;
        $this->typeHash = $typeHash;
        parent::__construct($context, $data);
    }

    /**
     * @return null
     */
    public function _prepareToRender()
    {
        $this->addColumn(
            'customer_info',
            [
                'label' => __('Customer Info')
            ]
        );
        $this->addColumn(
            'type_hash',
            [
                'label' => __('Hash')
            ]
        );
        $this->_addAfter = false;
        $this->_addButtonLabel = __('Add New Enrolment');
    }

    /**
     * @param string $columnName
     *
     * @return string
     *
     * @throws \Exception
     */
    public function renderCellTemplate($columnName)
    {
        if ($columnName == 'customer_info' && isset($this->_columns[$columnName])) {
            $options = $this->getElement()->getValues();
            $element = $this->elementFactory->create('select');
            $element->setForm(
                $this->getForm()
            )->setName(
                $this->_getCellInputElementName($columnName)
            )->setHtmlId(
                $this->_getCellInputElementId('<%- _id %>', $columnName)
            )->setValues(
                $options
            );

            return str_replace("\n", '', $element->getElementHtml());
        }

        if ($columnName == 'type_hash'
            && isset($this->_columns[$columnName])
        ) {
            $options = $this->typeHash->toOptionArray();
            $element = $this->elementFactory->create('select');
            $element->setForm(
                $this->getForm()
            )->setName(
                $this->_getCellInputElementName($columnName)
            )->setHtmlId(
                $this->_getCellInputElementId('<%- _id %>', $columnName)
            )->setValues(
                $options
            );

            return str_replace("\n", '', $element->getElementHtml());
        }

        return parent::renderCellTemplate($columnName);
    }

    /**
     * @param \Magento\Framework\DataObject $row
     *
     * @return void
     */
    public function _prepareArrayRow(\Magento\Framework\DataObject $row)
    {
        $optionExtraAttr = [];
        $optionExtraAttr['option_' . $this->getCustomerInfoRenderer()
            ->calcOptionHash($row->getData('customer_info'))]
                         = 'selected="selected"';
        $optionExtraAttr['option_' . $this->getTypeHashRenderer()
            ->calcOptionHash($row->getData('type_hash'))]
                         = 'selected="selected"';
        $row->setData(
            'option_extra_attrs',
            $optionExtraAttr
        );
    }

    /**
     * @return \Magento\Framework\View\Element\BlockInterface
     *
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getCustomerInfoRenderer()
    {
        $this->customerInfoRenderer = $this->getLayout()->createBlock(
            \CDP\Insight\Block\Adminhtml\System\Config\Select::class,
            '',
            ['data' => ['is_render_to_js_template' => true]]
        );

        return $this->customerInfoRenderer;
    }

    /**
     * @return \Magento\Framework\View\Element\BlockInterface
     *
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getTypeHashRenderer()
    {
        $this->typeHashRenderer = $this->getLayout()->createBlock(
            \CDP\Insight\Block\Adminhtml\System\Config\Select::class,
            '',
            ['data' => ['is_render_to_js_template' => true]]
        );

        return $this->typeHashRenderer;
    }

    /**
     * @return string
     *
     * @throws \Exception
     */
    public function _toHtml()
    {
        return '<input type="hidden" id="' . $this->getElement()->getHtmlId()
        . '"/>' . parent::_toHtml();
    }
}
