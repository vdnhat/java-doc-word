<?php
namespace CDP\Insight\Observer;

use Magento\Framework\Event\ObserverInterface;

class CustomerLoginObserver implements ObserverInterface
{
    /**
     * @var \CDP\Insight\Helper\Data
     */
    protected $helper;

    /**
     * @param \CDP\Insight\Helper\Data $helper
     */
    public function __construct(
        \Magento\Customer\Model\Session $customerSession,
        \CDP\Insight\Helper\Data $helper,
        \Magento\Framework\View\Element\Context $context,
        \Magento\Framework\View\Layout $layout,
        \Magento\Framework\View\LayoutFactory $layoutFactory
    )
    {
        $this->customerSession = $customerSession;
        $this->helper = $helper;
        $this->_layout = $context->getLayout();

        $this->_layoutFactory = $layoutFactory;
    }


    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return self
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $_SESSION['is_identify'] = 1;
        return;
    }

}