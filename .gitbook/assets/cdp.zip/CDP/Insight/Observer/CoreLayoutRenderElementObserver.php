<?php
namespace CDP\Insight\Observer;

use Magento\Framework\Event\ObserverInterface;

class CoreLayoutRenderElementObserver implements ObserverInterface
{
    /**
     * @var \CDP\Insight\Helper\Data
     */
    protected $helper;

    /**
     * @param \CDP\Insight\Helper\Data $helper
     */
    public function __construct(\CDP\Insight\Helper\Data $helper)
    {
        $this->helper = $helper;
    }
    
    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return self
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {

        if (!$this->helper->isEnabled()) {
            return $this;
        }

        $elementName = $observer->getData('element_name');

        if ($elementName != 'cdp_gtm_head') {
            return $this;
        }

        $transport = $observer->getData('transport');

        $html = $transport->getOutput();

        $scriptContent = $this->helper->getDataLayerScript();
        $html = $scriptContent . PHP_EOL . $html;


        $transport->setOutput($html);

        return $this;
    }
}