<?php
namespace CDP\Backend\Model\ResourceModel\License;

/**
 * Class Collection
 * @package CDP\Backend\Model\ResourceModel\License
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection 
{
    /**
     * @var string
     */
    protected $_idFieldName = 'id';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('CDP\Backend\Model\License', 'CDP\Backend\Model\ResourceModel\License');
    }
}
