<?php
namespace CDP\Backend\Model\ResourceModel;

/**
 * Class License
 * @package CDP\Backend\Model\ResourceModel
 */
class License extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('cdp_license', 'id');
    }
}
